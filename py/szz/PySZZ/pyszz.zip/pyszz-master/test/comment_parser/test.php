<?php
/*
php
  code
  */

 function foo($arg_1, $arg_2, $arg_n) {
     /* multi */

    echo "Example function.\n";

     # comment
         /** multi
         *
         *
         ***/
             // test
              # comment

    return $retval;
}

 /*
 php
  code
  */
?>