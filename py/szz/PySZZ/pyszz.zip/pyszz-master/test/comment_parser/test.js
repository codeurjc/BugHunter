
/* JavaScript
  code */
function test() {
    test = [];

    aaa = "//\n";
     /* multi */

         /** multi
         *
         *
         ***/
             // test
 }

 // comment
 // comment
 // comment

 /*
 JavaScript
  code
  */